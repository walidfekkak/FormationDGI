import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MotdepassePage } from './motdepasse';

@NgModule({
  declarations: [
    MotdepassePage,
  ],
  imports: [
    IonicPageModule.forChild(MotdepassePage),
  ],
})
export class MotdepassePageModule {}
