import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ToastController } from 'ionic-angular';
import { Api, ApiNative } from '../../providers';
import { User } from '../../providers';
import { Http, Headers, RequestOptions } from '@angular/http';
import { TranslateService } from '@ngx-translate/core';

@IonicPage()
@Component({
  selector: 'page-versements',
  templateUrl: 'versements.html',
})
export class VersementsPage {
 
  dateTo : string = this.api.datePipeTo(new Date().toISOString());

  dateFrom : string = this.api.datePipeFrom(new Date().toISOString());

  
  filter : any = {from : '2015-01-01', to: this.dateTo , type : null};
  
  data : any;
  MSSG_5YEARS: string;

  constructor(public navCtrl: NavController, public navParams: NavParams, private toastCtrl: ToastController,
    public api: Api, private apiNative : ApiNative, public user: User, public translateService: TranslateService) {
      this.translateService.get('MSSG_5YEARS').subscribe((value) => {
        this.MSSG_5YEARS = value;
      })

      this.filter.from = this.api.getDateFrom5years(); 
    this.loadData();

  }

  loadData(){
    const headers = new Headers();
    //headers.append('Content-Type', 'application/json');
    headers.append('token', this.user.token);
    headers.append('username', this.user.username);

       
    if(!this.api.checkDiffDate(this.filter.to , this.filter.from) ){

      let toast = this.toastCtrl.create({
        message: this.MSSG_5YEARS,
        duration: 3000,
        position: 'bottom'
      });
      toast.present();  
      return;

    }
    
    let body = { idFiscal : this.user._user.identifiantFiscal, 
                 //dateTo : '20170622',
                 dateTo : this.api.datePipeWs(this.filter.to),
                 //dateFrom : '20130101', 
                 dateFrom : this.api.datePipeWs(this.filter.from),
                 typeImpot: this.filter.type || '',
                 operation: 'versement' };


                 


    const options = new RequestOptions({headers: headers, params : body});

    let seq = this.api.get('providers/recette', body, options).map(resp => resp.json());
    // let headersApiNative = { 'token' : this.user.token, 'username' : this.user.username};
    // let seq = this.apiNative.get('providers/recette', body, options).map(resp => JSON.parse(resp.data));

    seq.subscribe((res: any) => {
      this.data = res.data;
    }, err => {
      console.error('ERROR', err);
    });
  }


  ionViewDidLoad() {
    console.log('ionViewDidLoad VersementsPage');
  }

  backToPrevious(){
    this.navCtrl.pop();
  }

  logout(){
    //this.navCtrl.pop();
    this.navCtrl.push('LoginPage');
  }

  redirect(pageName:string ='none', params = null,params1 = null ){
    if(pageName == 'none'){
        let toast = this.toastCtrl.create({
        message: "La logique de click n'est pas encore prête ! L'équipe de dév travail dessus...",
        duration: 3000,
        position: 'bottom'
      });
      toast.present();  
    }else if ( params != null ){
      console.log("here just");
      this.navCtrl.push(pageName,params);
    } else {
      this.navCtrl.setRoot(pageName,{},params1);
    }
  }

}

