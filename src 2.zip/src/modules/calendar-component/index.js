export { CalendarModule } from './src/calendar/calendar.module';
//# sourceMappingURL=index.js.map