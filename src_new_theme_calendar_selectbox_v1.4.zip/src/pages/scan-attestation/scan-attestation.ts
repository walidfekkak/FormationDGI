import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { ScanFormulairePage } from '../scan-formulaire/scan-formulaire';

import { BarcodeScanner } from '@ionic-native/barcode-scanner';


@IonicPage()
@Component({
  selector: 'page-scan-attestation',
  templateUrl: 'scan-attestation.html',
})
export class ScanAttestationPage {

  	constructor(private barcodeScanner: BarcodeScanner, public navCtrl: NavController, public navParams: NavParams, public toastCtrl: ToastController,) {
  	}

  	ionViewDidLoad() {
    	console.log('ionViewDidLoad ScanAttestationPage');
  	}
	redirectFormulaire(){
  		this.navCtrl.push('VerifAttestationPage');
	}
	scanQRCode(){


  	this.barcodeScanner.scan({formats: 'QR_CODE', prompt : "Placez le code QR dans le cadre de scan",
  			resultDisplayDuration: 0
		}).then((barcodeData) => {
  			console.log(barcodeData)
  			//alert(barcodeData.text)
  			//var url = "http://10.86.22.205:9080/verifAttest//verifyAttest.do?method=verify&type=DMOMV&annee=2021&numSerie=6d51fd6b4b976a&ifu=T204845";
  			//var url =  "http://10.86.22.205:9080/verifAttest//verifyAttest.do?method=verify&type=DIE&annee=2021&numSerie=b3dc9131b59e14&ifu=G256598"
  			//var url =  "http://192.168.250.20:9080/verifAttest/verifyAttest.do?method=verify&type=AttestationCA&annee=2021&numSerie=207f5e3f9eb5e&ifu=1004107"
  			//var url =  "http://192.168.250.20:9080/verifAttest/verifyAttest.do?method=verify&type=AttestationCA&annee=2021&numSerie=207f5e3f9eb5e&ifu=1004107"
  			//var url =  "http://192.168.250.20:9080/verifAttest/verifyAttest.do?method=verify&type=AttestationREGF&annee=2021&numSerie=207ef5f362829&ifu=1004107"
  			//var url =  "http://192.168.250.20:9080/verifAttest/verifyAttest.do?method=verify&type=AttestationExoLS&annee=2021&numSerie=208173b6b4887&ifu=40393781"
  			var url = barcodeData.text;
  			//url = url.replace('http://192.168.250.20:9080/verifAttest/verifyAttest.do?method=verify&', '')
  			url = url.substring(url.indexOf("&") + 1, url.length)
  			console.log('url')
  			console.log(url)
  			var params = url.split('&')
  			console.log('params')
  			console.log(params)
  			if(params.length < 4){
  				this.toastCtrl.create({
		          message: "Code QR invalide",
		          cssClass: 'danger',
		          duration: 2000,
		        }).present();
  				return;
  			}
  			
  			var type = params[0].split('=')[1];
  			var annee = params[1].split('=')[1];
  			var numSerie = params[2].split('=')[1];
  			var ifu = params[3].split('=')[1];

      	var params1 = {
      		type: type,
      		identifiant: ifu,
      		code_verification: numSerie,
      		annee: annee,
      	}
  			this.navCtrl.push('VerifAttestationPage', {params: params1});

	      	//self.barcode = "6111242923140"; // 4823077625572 // @TEST
	      	//self.barcode = barcodeData.text;
	      	//self.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
	      	//self.searchForProduct(self.barcode);
	     // Success! Barcode data is here
	    }, (err) => {
	        // An error occurred
	        this.toastCtrl.create({
	          message: "Erreur lors de l'appel du scanner",
	          cssClass: 'danger',
	          duration: 2000,
	        }).present();
	        //self.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
	    });

	}
}
