import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController, LoadingController } from 'ionic-angular';
import { Api, ApiNative } from '../../providers';
import { User } from '../../providers';
//import { HttpHeaders } from '@angular/common/http';
import {Http, Headers, RequestOptions} from '@angular/http';
import {LoginPage} from '../login/login'

import { FileTransfer, FileUploadOptions, FileTransferObject } from '@ionic-native/file-transfer';
import { File } from '@ionic-native/file';
import { FileOpener } from '@ionic-native/file-opener';
import { TranslateService } from '@ngx-translate/core';

@IonicPage()
@Component({
  selector: 'page-verif-attestation',
  templateUrl: 'verif-attestation.html',
})
export class VerifAttestationPage {
  /*type: any='BulletinIF';
  identifiant: any ='1004107' ;
  annee: any = '2021';
  code_verification: any ='8e2feaf7874ac';*/
  type: any='';
  identifiant: any ='' ;
  annee: any = '';
  code_verification: any ='';
  fileTransfer: FileTransferObject;


  	constructor(public translateService:TranslateService,public loadingController : LoadingController,public navCtrl: NavController, public navParams: NavParams,
    public api: Api, public apiNative: ApiNative , public user: User,private toastCtrl:ToastController ,
    private transfer: FileTransfer, private file: File, private fileOpener: FileOpener) {

  	}

  	ionViewDidLoad() {
    	console.log('ionViewDidLoad VerifAttestationPage');
      var params = this.navParams.get('params') || null;

      if(params){
        this.type = params.type;
        this.identifiant = params.identifiant;
        this.code_verification = params.code_verification;
        this.annee = params.annee;
        this.submit();
      }
  	}


    submit(){
      const headers = new Headers();

      let body = { 
        idFiscal: this.identifiant,
        typeAttestation: this.type,
        annee: this.annee,
        codeVerif: this.code_verification
      };

      const options = new RequestOptions({headers: headers, params : body});

      let seq = this.api.getAttestation('verifieAttestations', body, options, 'attestations/rest').map(resp => resp.json());

      seq.subscribe((res: any) => {
        console.log(res);

        if(res.status_code == 302){
          this.toastCtrl.create({
              message: 'Attesation trouvée ' + res.message,
              duration: 3000
          }).present();

          let  codeAttestation = res.message;

          let urlPdf = this.api.getUrl('TelechargerAttestationExoP','attestations/rest');
          urlPdf+= '?pdfID='+ codeAttestation;  
          this.fileTransfer= this.transfer.create();
          this.fileTransfer.download(urlPdf, this.file.dataDirectory + 'attestation'+ codeAttestation +'.pdf').then((entry) => {
              console.log('download complete: ' + entry.toURL());
              console.log('fileOpener: ' + entry.toURL());
              this.fileOpener.open(entry.toURL(), 'application/pdf');
              
              //this.fileOpener.open(entry.toURL(), 'application/pdf')
              //.then(() => console.log('File is opened'))
              //.catch(e => console.log('Error opening file', e));
              
          }, (error) => {
            // handle error
            console.log(error);
          });

        }else if(res.status_code == 404){
          this.toastCtrl.create({
              message: 'Attesatin non trouvée ',
              duration: 3000
          }).present();
        }else{
          this.toastCtrl.create({
              message: 'Unhandled status code ' + res.status_code,
              duration: 3000
          }).present();
        }
        
      }, err => {
        console.error('ERROR', err);
        console.log(err);
        let toast = this.toastCtrl.create({
            message: 'Vos données sont incorrectes. Merci de réessayer.'
           , duration: 3500,
            position: 'bottom'
          });
          toast.present();
      });
    }
	
}
