export { CalendarModule } from './src/calendar/calendar.module';
